



	<footer style="background-color: #003A6A; margin-top: 65px;">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <p style="color:white; font-family:verdana; font-size:13px; text-align:center; padding:10px;">
        Copyright <?php echo date('Y'); ?> © NIT Jalandhar<br />
        Developed by: Computer Centre, Dr. B.R. Ambedkar National Institute of Technology, Jalandhar
        </p>
    </div>
  </div>
</div>
</footer>
