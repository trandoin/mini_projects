
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=A45DEPWLRZK5S)

# Bootstrap Form Builder
A simple bootstrap form builder
Checkout the demo here [https://balbinder.com/projects/form-builder/](http://balbinder.com/projects/form-builder/)

Simply clone or download the code and start using it!
