  <footer class="main-footer " style="margin-top: 80px;">
  	<div class="container-fluid">
  	<div class="row text-center bg-info" style=" min-height: 100px;">
  		<div class="col-lg-12 py-5">
    <strong>Copyright &copy; 2020 <a href="http://trando.in/">Team Trando</a>.</strong>
    All rights reserved.
    </div>
    <div class="float-right d-none d-sm-inline-block"></div>
    		</div>
  	</div>
  </footer>