<?php 

$DSN ='mysql:host = localhost; dbname=cms';  #NOT ADD any Space between dbname & '=' sign
$ConnectingDB = new PDO($DSN,'root','');







 ?>